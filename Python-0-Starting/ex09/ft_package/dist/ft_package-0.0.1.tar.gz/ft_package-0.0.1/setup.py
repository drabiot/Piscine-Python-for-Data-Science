from setuptools import setup, find_packages

setup(
    name='ft_package',
    version='0.0.1',
	description='A sample test package',
    packages=find_packages(),
    install_requires=[],
    author='tchartie',
	author_email='tchartie@student.42angouleme.fr',
)
